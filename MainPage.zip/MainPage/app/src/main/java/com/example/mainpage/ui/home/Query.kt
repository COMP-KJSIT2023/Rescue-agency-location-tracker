package com.example.mainpage.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.mainpage.R
import com.example.mainpage.databinding.FragmentHomeBinding
import com.example.mainpage.databinding.QueryLayoutBinding

class Query : Fragment() {

    private var _binding : QueryLayoutBinding? = null
    private lateinit var search : EditText


    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val homeViewModel =
            ViewModelProvider(this).get(HomeViewModel::class.java)

        _binding = QueryLayoutBinding.inflate(inflater, container, false)
        val root: View = binding.root






        return root
    }





    }
}





}